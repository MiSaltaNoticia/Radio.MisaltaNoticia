const form = document.querySelector('form');

form.addEventListener('submit', (event) => {
    event.preventDefault();

    const nombre = document.querySelector('#nombre').value;
    const email = document.querySelector('#email').value;
    const mensaje = document.querySelector('#mensaje').value;

    // Validar los datos

    if (nombre === '' || email === '' || mensaje === '') {
        alert('Todos los campos son obligatorios');
        return;
    }

    // Enviar los datos a enviar.php

    const data = new FormData(form);

    fetch('enviar.php', {
        method: 'POST',
        body: data,
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                alert('Mensaje enviado correctamente');
                form.reset();
            } else {
                alert('Error al enviar el mensaje');
            }
        });
});
