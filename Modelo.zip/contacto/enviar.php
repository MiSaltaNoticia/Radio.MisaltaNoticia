<?php

// Recibir los datos del formulario

$nombre = $_POST['nombre'];
$email = $_POST['email'];
$mensaje = $_POST['mensaje'];

// Configurar el correo electrónico

$destinatario = 'misaltanoticia@gmail.com';
$asunto = 'Formulario de contacto';
$cuerpo = "Nombre: $nombre\nCorreo electrónico: $email\nMensaje: $mensaje";

// Enviar el correo electrónico

mail($destinatario, $asunto, $cuerpo);

// Responder al formulario

$respuesta = array(
    'success' => true,
);

echo json_encode($respuesta);

?>
